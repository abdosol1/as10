export function solveMatrix(originalMatrix) {
  // Create a deep copy of the matrix
  let matrix = originalMatrix.map(row => [...row]);
  const n = matrix.length;

  for (let i = 0; i < n; i++) {
    // Find pivot
    let maxElement = Math.abs(matrix[i][i]);
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(matrix[k][i]) > maxElement) {
        maxElement = Math.abs(matrix[k][i]);
        maxRow = k;
      }
    }

    // Swap maximum row with current row
    if (maxRow !== i) {
      for (let k = i; k <= n; k++) {
        let tmp = matrix[i][k];
        matrix[i][k] = matrix[maxRow][k];
        matrix[maxRow][k] = tmp;
      }
    }

    // Make all rows below this one 0 in current column
    for (let k = i + 1; k < n; k++) {
      let factor = matrix[k][i] / matrix[i][i];
      for (let j = i; j <= n; j++) {
        matrix[k][j] -= factor * matrix[i][j];
      }
    }
  }

  // Back substitution
  let x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    x[i] = matrix[i][n];
    for (let j = i + 1; j < n; j++) {
      x[i] -= matrix[i][j] * x[j];
    }
    x[i] /= matrix[i][i];
  }

  // Update the solution in matrix format
  return matrix.map((row, i) => [...row.slice(0, -1), x[i]]);
}