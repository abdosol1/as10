import React from 'react';
import { TextField } from '@mui/material';

function MatrixInput({ matrix, onInputChange }) {
  return (
    <div className="grid gap-6 mb-8">
      {matrix.map((row, i) => (
        <div key={i} className="flex gap-4 justify-center">
          {row.map((val, j) => (
            <TextField
              key={j}
              type="number"
              value={val || ''}
              onChange={(e) => onInputChange(i, j, e.target.value)}
              label={j === 3 ? 'Constants' : `x${j + 1}`}
              variant="outlined"
              size="small"
              sx={{
                width: '100px',
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: '#000',
                    borderWidth: '2px',
                  },
                  '&:hover fieldset': {
                    borderColor: '#009736',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#009736',
                  },
                },
                '& .MuiInputLabel-root': {
                  '&.Mui-focused': {
                    color: '#009736',
                  },
                },
              }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}