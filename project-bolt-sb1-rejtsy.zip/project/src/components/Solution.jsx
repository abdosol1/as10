import React from 'react';

function Solution({ matrix }) {
  return (
    <div className="solution-container mt-6 text-center">
      <h2 className="text-2xl font-bold mb-6">Solution:</h2>
      <div className="grid grid-cols-3 gap-4">
        {matrix.map((row, i) => (
          <div key={i} className="p-3 rounded-lg bg-opacity-10 bg-black">
            x{i + 1} = {Number(row[3]).toFixed(4)}
          </div>
        ))}
      </div>
    </div>
  );
}