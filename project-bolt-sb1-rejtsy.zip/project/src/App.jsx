import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';

function App() {
  const [matrix, setMatrix] = useState(Array(3).fill().map(() => Array(4).fill(0)));

  const handleInputChange = (row, col, value) => {
    const newMatrix = matrix.map(r => [...r]);
    newMatrix[row][col] = parseFloat(value) || 0;
    setMatrix(newMatrix);
  };

  const solveMatrix = () => {
    let m = matrix.map(row => [...row]);
    
    // Gauss-Jordan Elimination
    for (let i = 0; i < 3; i++) {
      // Make diagonal element 1
      let pivot = m[i][i];
      if (pivot === 0) return null;
      
      for (let j = 0; j <= 3; j++) {
        m[i][j] /= pivot;
      }
      
      // Make other elements in column 0
      for (let k = 0; k < 3; k++) {
        if (k !== i) {
          let factor = m[k][i];
          for (let j = 0; j <= 3; j++) {
            m[k][j] -= factor * m[i][j];
          }
        }
      }
    }

    setMatrix(m);
  };

  return (
    <div className="palestinian-flag-bg">
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-6 text-red-600">
            Palestinian Flag Matrix Solver
          </h1>
          
          <div className="grid gap-4 mb-6">
            {matrix.map((row, i) => (
              <div key={i} className="flex gap-4 justify-center">
                {row.map((val, j) => (
                  <TextField
                    key={j}
                    type="number"
                    value={val}
                    onChange={(e) => handleInputChange(i, j, e.target.value)}
                    label={j === 3 ? 'Constants' : `x${j + 1}`}
                    variant="outlined"
                    size="small"
                    sx={{
                      width: '100px',
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderColor: '#000',
                        },
                        '&:hover fieldset': {
                          borderColor: '#009736',
                        },
                      },
                    }}
                  />
                ))}
              </div>
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="contained"
              onClick={solveMatrix}
              sx={{
                backgroundColor: '#000',
                '&:hover': {
                  backgroundColor: '#009736',
                },
              }}
            >
              Solve Matrix
            </Button>
          </div>

          <div className="mt-6 text-center">
            <h2 className="text-2xl font-semibold mb-4 text-green-600">Solution:</h2>
            {matrix.map((row, i) => (
              <div key={i} className="mb-2">
                x{i + 1} = {row[3].toFixed(4)}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;